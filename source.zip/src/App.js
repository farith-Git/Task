import React, { useState, useEffect } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import FlimsList from './components/FlimsList';

const App = () => {
  const [movies, setMovies] = useState([]);
  const [language, setLanguage] = useState('en');
  const [minReleaseDate, setMinReleaseDate] = useState('');
  const [maxReleaseDate, setMaxReleaseDate] = useState('');
  const [selectedGenres, setSelectedGenres] = useState([]);
  const [userScoreMin, setUserScoreMin] = useState(1);
  const [userScoreMax, setUserScoreMax] = useState(10);
  const [selectedCertifications, setSelectedCertifications] = useState([]);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [shareUrl, setShareUrl] = useState('');

  const genres = [
    { id: 28, name: 'Action' },
    { id: 12, name: 'Adventure' },
    { id: 16, name: 'Animation' },
  ];

  const certifications = [
    { id: 'U', name: 'U' },
    { id: 'A', name: 'A' },
    { id: 'UA', name: 'U/A' },
  ];

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        let requestUrl = `https://api.themoviedb.org/3/discover/movie?api_key=653a8ae5222bfda47688dd1920cc0dbf&with_original_language=${language}&sort_by=popularity.desc&vote_average.gte=${userScoreMin}&vote_average.lte=${userScoreMax}&release_date.gte=${minReleaseDate}&release_date.lte=${maxReleaseDate}&with_genres=${selectedGenres}&certification_country=IN&certification=${selectedCertifications.join('|')}&page=${page}`;
        setShareUrl(requestUrl)
        const response = await axios.get(requestUrl);
        setMovies(response.data.results);
        setTotalPages(response.data.total_pages);
        setIsLoading(false)
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, [language, minReleaseDate, maxReleaseDate, selectedGenres, selectedCertifications, userScoreMax, userScoreMin, page]);

  const handleNextPage = () => {
    setPage((prevPage) => Math.min(prevPage + 1, totalPages));
  };

  const handlePrevPage = () => {
    setPage((prevPage) => Math.max(prevPage - 1, 1));
  };


  const changeGenre = (genreId) => {
    setSelectedGenres((prevGenres) => {
      if (prevGenres.includes(genreId)) {
        return prevGenres.filter((id) => id !== genreId);
      } else {
        return [...prevGenres, genreId];
      }
    });
  };

  const changeCertification = (certificationId) => {
    setSelectedCertifications((prevCertifications) => {
      if (prevCertifications.includes(certificationId)) {
        return prevCertifications.filter((id) => id !== certificationId);
      } else {
        return [...prevCertifications, certificationId];
      }
    });
  };



  const handleShareButtonClick = () => {
    const shareURL = `${window.location.origin}${window.location.pathname}?language=${language}&sort_by=popularity.desc&userScoreMin=${userScoreMin}&userScoreMax=${userScoreMax}&minReleaseDate=${minReleaseDate}&maxReleaseDate=${maxReleaseDate}&selectedGenres=${selectedGenres.join(',')}&certification_country=IN&selectedCertifications=${selectedCertifications.join('|')}`;
    window.open(shareURL, '_blank');
  };


  useEffect(() => {
    const getQueryParam = (param, defaultValue) => {
      const params = new URLSearchParams(window.location.search);
      return params.get(param) || defaultValue;
    };

    setLanguage(getQueryParam('language', 'en'));
    setUserScoreMin(parseInt(getQueryParam('userScoreMin', 1)));
    setUserScoreMax(parseInt(getQueryParam('userScoreMax', 10)));
    setMinReleaseDate(getQueryParam('minReleaseDate', ''));
    setMaxReleaseDate(getQueryParam('maxReleaseDate', ''));
    setSelectedGenres(getQueryParam('selectedGenres', '').split(','));
    
    if(getQueryParam('selectedCertifications')) {
      setSelectedCertifications(getQueryParam('selectedCertifications', '').split('|'));
   }
  }, []);

  return (
    <div>
      

      <div className="container mb-3 mt-3">
        <div className="row">
          
          <div className="col-md-12 mb-4">
            <h1 className="text-center ">Movies List</h1>
          </div>

          <div className="col-md-12 mb-4 text-right">
            <button type="button" className="btn btn-success share-btn" onClick={handleShareButtonClick}>Share URL</button>
          </div>

        </div>

        <div className="row mb-4">

          <div className="col-md-3">
            
            <div className="form-group">
              <label className="mb-2"> <strong> Select Language </strong> </label>
              <select className="form-select" aria-label="Default select example" value={language} onChange={(e) => setLanguage(e.target.value)}>
                <option value="en">English</option>
                <option value="es">Spanish</option>
                <option value="fr">French</option>
                <option value="ta">Tamil</option>
              </select>
            </div>
          </div>

          <div className="col-md-3">
            <div className="form-group">
              <label className="mb-2"> <strong> Select Genre </strong> </label>
              {genres.map((genre) => (
                <div key={genre.id} className="form-check">
                  <input
                    type="checkbox"
                    className="form-check-input"
                    id={`genre-${genre.id}`}
                    checked={selectedGenres.includes(genre.id)}
                    onChange={() => changeGenre(genre.id)}
                  />
                  <label className="form-check-label" htmlFor={`genre-${genre.id}`}> {genre.name} </label>
                </div>
              ))}
            </div>
          </div>

          <div className="col-md-2">
            <div className="form-group">
              <label className="mb-2"> <strong> Certification </strong> </label>
              {certifications.map((certification) => (
                <div key={certification.id} className="form-check">
                  <input
                    type="checkbox"
                    className="form-check-input"
                    id={`certification-${certification.id}`}
                    checked={selectedCertifications.includes(certification.id)}
                    onChange={() => changeCertification(certification.id)}
                  />
                  <label className="form-check-label" htmlFor={`certification-${certification.id}`}>
                    {certification.name}
                  </label>
                </div>
              ))}
            </div>
          </div>

          <div className="col-md-2">
            <div className="form-group">
              <label  className="mb-2"> <strong> User Score From </strong> </label>
              <input type="number" value={userScoreMin} onChange={(e) => setUserScoreMin(e.target.value)} min="1" max="10" />
            </div>

            <div className="form-group">
              <label  className="mb-2"> <strong> User Score To </strong> </label>
              <input type="number" value={userScoreMax} onChange={(e) => (e.target.value > userScoreMin) ? setUserScoreMax(e.target.value) : ''} min="1" max="10" />
            </div>
          </div>

          <div className="col-md-2">
            <div className="form-group">
              <label  className="mb-2"> <strong> Release Date From </strong> </label>
              <input type="date" value={minReleaseDate} onChange={(e) => setMinReleaseDate(e.target.value)} />
            </div>

            <div className="form-group">
              <label  className="mb-2"> <strong> Release Date To </strong> </label>
              <input type="date" value={maxReleaseDate} onChange={(e) => setMaxReleaseDate(e.target.value)} />
            </div>
          </div>
        
        </div>
      </div>

      { !isLoading ?

        movies.length > 0 ?

        <>

        <FlimsList movies={movies} /> 

        <div className="d-grid gap-2 d-md-flex justify-content-md-center mt-3 mb-3">
          <button  onClick={handlePrevPage} disabled={page === 1} className="btn btn-primary me-md-2" type="button"> Previous Page </button>
          <span> Page {page} of {totalPages} </span>
          <button className="btn btn-primary" type="button" onClick={handleNextPage} disabled={page === totalPages}> Next Page </button>
        </div>

        </>

        :

        <div className="container">
          <div className="row  text-center mb-5 mt-5">
            <h4> No More Records Found. </h4>
          </div>
        </div>

        :

        <div className="container">
          <div className="row  text-center mb-5 mt-5">
            <h4> Loading..... </h4>
          </div>
        </div>
      }


      

      

    </div>
  );
};

export default App;