import React from 'react';
import moment from 'moment';

const FlimsList = ({ movies }) => {
  return (
    <>

      <div className="container">
        <div className="row row-cols-1 row-cols-lg-2 row-cols-xl-5">
        {movies.map((movie) => (
          <div className="col mb-2" key={movie.title}>
            <div className="card radius-0">
              <div className="card-body text-center">
                <img src={"https://image.tmdb.org/t/p/w500"+movie.poster_path} width="150" height="200" className="" alt={movie.title} />
                <p className="mb-0 mt-2"> {movie.title} </p>
                <p className="mb-3">{moment(movie.release_date).format('DD, MMMM YYYY')}</p>
                <div className="d-grid"> <strong>Rating : {movie.vote_average}</strong>  </div>
              </div>
            </div>
          </div>
        ))}
        </div>
      </div>

    </>
  );
};

export default FlimsList;